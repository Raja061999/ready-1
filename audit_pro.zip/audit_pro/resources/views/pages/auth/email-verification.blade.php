@extends('layouts.app')

@section('no_header')
@endsection

@section('no_sidebar')
@endsection

@section('no_footer')
@endsection

@section('content')
    <div class="container-fuild">
        <div class="w-100 overflow-hidden position-relative flex-wrap d-block vh-100">
            <div class="row justify-content-center align-items-center vh-100 overflow-auto flex-wrap">
                <div class="col-md-4 mx-auto vh-100">
                    <form action="{{ route('password.reset_form') }}" class="digit-group vh-100">
                        <div class="vh-100 d-flex flex-column justify-content-between p-4 pb-0">
                            <div class="mx-auto mb-5 text-center">
                                <img src="" class="img-fluid" alt="Logo">
                            </div>
                            <div>
                                <div class="text-center mb-3">
                                    <h2 class="mb-2">Email OTP Verification</h2>
                                    @php
                                        $email = session('email');
                                        function maskEmail($email)
                                        {
                                            $parts = explode('@', $email);
                                            $name = $parts[0];
                                            $domain = $parts[1] ?? '';
                                            $maskedName =
                                                substr($name, 0, 2) . str_repeat('*', max(0, strlen($name) - 2));
                                            return $maskedName . '@' . $domain;
                                        }
                                    @endphp
                                    <p class="mb-0">
                                        OTP sent to your Email Address: <strong>{{ maskEmail($email) }}</strong>
                                    </p>
                                </div>

                                <div class="text-center otp-input">
                                    <div class="d-flex align-items-center mb-3">
                                        <input type="text"
                                            class="rounded w-100 py-sm-3 py-2 text-center fs-26 fw-bold me-3" id="digit-1"
                                            name="digit-1" data-next="digit-2" maxlength="1">
                                        <input type="text"
                                            class="rounded w-100 py-sm-3 py-2 text-center fs-26 fw-bold me-3" id="digit-2"
                                            name="digit-2" data-next="digit-3" data-previous="digit-1" maxlength="1">
                                        <input type="text"
                                            class="rounded w-100 py-sm-3 py-2 text-center fs-26 fw-bold me-3" id="digit-3"
                                            name="digit-3" data-next="digit-4" data-previous="digit-2" maxlength="1">
                                        <input type="text" class="rounded w-100 py-sm-3 py-2 text-center fs-26 fw-bold"
                                            id="digit-4" name="digit-4" data-previous="digit-3" maxlength="1">
                                    </div>

                                    <!-- Countdown Timer -->
                                    <div class="badge bg-danger-transparent mb-3">
                                        <p class="d-flex align-items-center">
                                            <i class="ti ti-clock me-1"></i><span id="otp-timer">10:00</span>
                                        </p>
                                    </div>

                                    <div class="mb-3 d-flex justify-content-center">
                                        <p class="text-gray-9">Didn't get the OTP? <a href="javascript:void(0);"
                                                class="text-primary">Resend OTP</a></p>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <button type="submit" class="btn btn-primary w-100">Verify & Proceed</button>
                                </div>
                            </div>

                            <div class="mt-5 pb-4 text-center">
                                <p class="mb-0 text-gray-9">&copy; {{ date('Y') }} - Company Name</p>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Countdown Script -->
    <script>
        let timerElement = document.getElementById("otp-timer");
        let timeLeft = 600; // 10 minutes in seconds

        function updateTimer() {
            let minutes = Math.floor(timeLeft / 60);
            let seconds = timeLeft % 60;

            timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

            if (timeLeft > 0) {
                timeLeft--;
                setTimeout(updateTimer, 1000);
            } else {
                timerElement.textContent = "Expired";
            }
        }

        updateTimer();
    </script>
@endsection
