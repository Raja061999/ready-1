@extends('layouts.app')

@section('no_header')
@endsection

@section('no_sidebar')
@endsection

@section('no_footer')
@endsection

@section('content')
    <div class="container-fluid min-vh-100 d-flex justify-content-center align-items-center">
        <div class="col-md-4">
            <form method="POST" action="{{ route('login.post') }}">
                @csrf
                <div class="d-flex flex-column justify-content-between p-4">

                    {{-- Logo --}}
                    <div class="mb-5 text-center">
                        <img src="{{ asset('images/logo.png') }}" class="img-fluid" alt="Logo">
                    </div>

                    {{-- Form Heading --}}
                    <div class="text-center mb-3">
                        <h2 class="mb-2">Sign In</h2>
                        <p class="mb-0">Please enter your details to sign in</p>
                    </div>

                    {{-- Email --}}
                    <div class="mb-3">
                        <label class="form-label">Email Address</label>
                        <div class="input-group">
                            <input type="text" name="email" value="{{ old('email') }}" class="form-control border-end-0">
                            <span class="input-group-text border-start-0">
                                <i class="ti ti-mail"></i>
                            </span>
                        </div>
                    </div>

                    {{-- Password --}}
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <div class="pass-group">
                            <input type="password" name="password" class="pass-input form-control">
                            <span class="ti toggle-password ti-eye-off"></span>
                        </div>
                    </div>

                    {{-- Remember & Forgot --}}
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <div class="form-check form-check-md mb-0">
                            <input class="form-check-input" name="remember" id="remember_me" type="checkbox">
                            <label for="remember_me" class="form-check-label mt-0">Remember Me</label>
                        </div>
                        <div class="text-end">
                            <a href="{{ route('password.request') }}" class="link-danger">Forgot Password?</a>
                        </div>
                    </div>

                    {{-- Submit --}}
                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary w-100">Sign In</button>
                    </div>

                    {{-- Footer --}}
                    <div class="mt-5 pb-4 text-center">
                        <p class="mb-0 text-gray-9">&copy; {{ date('Y') }} - Company Name</p>
                    </div>

                </div>
            </form>
        </div>
    </div>
@endsection
