<div class="col-lg-12">
    <div class="card">
        <div class="card-body">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body pb-1">
                        <div class="border-bottom mb-3 pb-3">
                            <h4>Income Tax Act</h4>
                        </div>
                            <div class="row">
                                <div class="col-xxl-4 col-xl-4 d-flex">
                                    <form action="{{ route('document.store') }}" method="POST" enctype="multipart/form-data">
                                        @csrf
                                    <div class="card flex-fill">
                                        <div class="card-body">
                                            <div class="border-bottom mb-3 pd-3">
                                                <div class="d-flex justify-content-between align-items-center mb-2">
                                                    <div class="d-flex align-items-center gap-3">
                                                        <span class="avatar rounded-circle bg-secondary mr-2">
                                                            <i class="ti ti-browser fs-16"></i>
                                                        </span>
                                                        {{-- <span class="avatar avatar-xl p-2 me-2 bg-light flex-shrink-0">
                                                            <img src="https://smarthr.dreamstechnologies.com/laravel/template/public/build/img/settings/smtp.svg" alt="Profile">
                                                        </span> --}}
                                                        <h5>TDS Return (Salary)</h5>
                                                    </div>
                                                    @include('pages.document.components.status-button')

                                                    {{-- <div class="form-check form-switch">
                                                        <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault">
                                                    </div> --}}
                                                </div>
                                                <p>Used to send emails safely and easily via PHP code from a web server.</p>
                                                <div class="custom-file-container" >
                                                    <label>Upload (Single File) <a href="javascript:void(0)"
                                                            class="custom-file-container__image-clear" title="Clear Image">x</a></label>
                                                    <label class="custom-file-container__custom-file">
                                                        <input type="file"
                                                            class="custom-file-container__custom-file__custom-file-input" name="file">
                                                        <input type="hidden" name="MAX_FILE_SIZE" value="10485760">
                                                        <span class="custom-file-container__custom-file__custom-file-control"></span>
                                                    </label>
                                                    <input type="hidden" name="category" value="income_tax">
                                                    <input type="hidden" name="sub_category" value="tds_return">
                                                    {{-- <div class="custom-file-container__image-preview"></div> --}}
                                                </div>

                                            </div>
                                            @include('pages.document.components.button')


                                        </div>
                                    </div>
                                    </form>
                                </div>
                                <div class="col-xxl-4 col-xl-4 d-flex">
                                    <form action="{{ route('document.store') }}" method="POST" enctype="multipart/form-data">
                                        @csrf
                                    <div class="card flex-fill">
                                        <div class="card-body">
                                            <div class="border-bottom mb-3">
                                                <div class="d-flex justify-content-between align-items-center mb-2">
                                                    <div class="d-flex align-items-center gap-3">
                                                        <span class="avatar rounded-circle bg-secondary mr-2">
                                                            <i class="ti ti-browser fs-16"></i>
                                                        </span>
                                                        <h5>TDS Payment (Challan)</h5>
                                                    </div>
                                                    @include('pages.document.components.status-button')

                                                    {{-- <div class="form-check form-switch">
                                                        <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault">
                                                    </div> --}}
                                                </div>
                                                <p>Used to send emails safely and easily via PHP code from a web server.</p>
                                                <div class="custom-file-container" >
                                                    <label>Upload (Single File) <a href="javascript:void(0)"
                                                            class="custom-file-container__image-clear" title="Clear Image">x</a></label>
                                                    <label class="custom-file-container__custom-file">
                                                        <input type="file"
                                                            class="custom-file-container__custom-file__custom-file-input" name="file">
                                                        <input type="hidden" name="MAX_FILE_SIZE" value="10485760">
                                                        <span class="custom-file-container__custom-file__custom-file-control"></span>
                                                    </label>
                                                    <input type="hidden" name="category" value="income_tax">
                                                    <input type="hidden" name="sub_category" value="tds_payment">
                                                    {{-- <div class="custom-file-container__image-preview"></div> --}}
                                                </div>

                                            </div>
                                            @include('pages.document.components.button')

                                            {{-- <div class="d-flex align-items-center justify-content-between">
                                                <button class="btn btn-sm d-inline-flex align-items-center btn-dark" type="submit">
                                                    <i class="ti ti-checks me-1"></i>
                                                        Upload
                                                </button>
                                                <button class="btn btn-sm d-inline-flex align-items-center btn-success" type="submit">
                                                    <i class="ti ti-checks me-1"></i>
                                                        Approve
                                                </button>
                                                <button class="btn btn-sm d-inline-flex align-items-center btn-danger" type="submit">
                                                    <i class="ti ti-checks me-1"></i>
                                                        Reject
                                                </button>


                                            </div> --}}

                                        </div>
                                    </div>
                                    </form>
                                </div>
                                <div class="col-xxl-4 col-xl-4 d-flex">
                                    <form action="{{ route('document.store') }}" method="POST" enctype="multipart/form-data">
                                        @csrf
                                    <div class="card flex-fill">
                                        <div class="card-body">
                                            <div class="border-bottom mb-3">
                                                <div class="d-flex justify-content-between align-items-center mb-2">
                                                    <div class="d-flex align-items-center gap-3">
                                                        <span class="avatar rounded-circle bg-secondary mr-2">
                                                            <i class="ti ti-browser fs-16"></i>
                                                        </span>
                                                        <h5>Form 16</h5>
                                                    </div>
                                                    @include('pages.document.components.status-button')

                                                    {{-- <div class="form-check form-switch">
                                                        <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault">
                                                    </div> --}}
                                                </div>
                                                <p>Used to send emails safely and easily via PHP code from a web server.</p>
                                                <div class="custom-file-container" >
                                                    <label>Upload (Single File) <a href="javascript:void(0)"
                                                            class="custom-file-container__image-clear" title="Clear Image">x</a></label>
                                                    <label class="custom-file-container__custom-file">
                                                        <input type="file"
                                                            class="custom-file-container__custom-file__custom-file-input" name="file">
                                                        <input type="hidden" name="MAX_FILE_SIZE" value="10485760">
                                                        <span class="custom-file-container__custom-file__custom-file-control"></span>
                                                    </label>
                                                    <input type="hidden" name="category" value="income_tax">
                                                    <input type="hidden" name="sub_category" value="form_16">
                                                    {{-- <div class="custom-file-container__image-preview"></div> --}}
                                                </div>

                                            </div>
                                            @include('pages.document.components.button')
                                        </div>
                                    </div>
                                    </form>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end card body -->
    </div>
</div>
