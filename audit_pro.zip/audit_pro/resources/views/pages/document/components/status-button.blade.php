<button class="btn btn-sm btn-outline-warning d-inline-flex align-items-center" type="submit">
    Pending
</button>
