<div class="d-flex align-items-center justify-content-start gap-2">
    <button class="btn btn-sm d-inline-flex align-items-center btn-dark" type="submit">
        <i class="ti ti-checks me-1"></i>
            Upload
    </button>
    <button class="btn btn-sm d-inline-flex align-items-center btn-success">
        <i class="ti ti-checks me-1"></i>
            Approve
    </button>
    <button class="btn btn-sm d-inline-flex align-items-center btn-success">
        <i class="ti ti-checks me-1"></i>
            Approved
    </button>

    <button class="btn btn-sm d-inline-flex align-items-center btn-danger" >
        <i class="ti ti-checks me-1"></i>
            Reject
    </button>
    <button class="btn btn-sm d-inline-flex align-items-center btn-danger" >
        <i class="ti ti-checks me-1"></i>
            Rejected
    </button>

    {{-- <a href="#" data-bs-toggle="modal" data-bs-target="#phpmailersettings" class="btn btn-icon btn-sm text-gray-5 fs-20"><i class="ti ti-settings"></i></a> --}}
</div>

