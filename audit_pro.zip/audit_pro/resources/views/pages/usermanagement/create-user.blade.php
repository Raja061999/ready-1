@extends('layouts.app')

@section('content')
    <div class="content container my-4">
        <div class="card shadow-sm">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h5 class="mb-0">Create User</h5>
            </div>

            <form action="{{ route('user.store-user') }}" method="POST">
                @csrf
                <div class="card-body">
                    <div class="row g-3">

                        {{-- Username --}}
                        <div class="col-md-6">
                            <label class="form-label">Full Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="full_name" value="{{ old('full_name') }}">
                            @error('full_name')
                                <span class="text-danger small">{{ $message }}</span>
                            @enderror
                        </div>

                        {{-- Email --}}
                        <div class="col-md-6">
                            <label class="form-label">Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" name="email" value="{{ old('email') }}">
                            @error('email')
                                <span class="text-danger small">{{ $message }}</span>
                            @enderror
                        </div>

                        {{-- Password --}}
                        <div class="col-md-6">
                            <label class="form-label">Password <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" name="password" value="{{ old('password') }}">
                            @error('password')
                                <span class="text-danger small">{{ $message }}</span>
                            @enderror
                        </div>

                        {{-- Confirm Password --}}
                        <div class="col-md-6">
                            <label class="form-label">Confirm Password <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" name="password_confirmation" value="{{ old('password_confirmation') }}">
                            @error('password_confirmation')
                                <span class="text-danger small">{{ $message }}</span>
                            @enderror
                        </div>

                        {{-- Phone Number --}}
                        <div class="col-md-6">
                            <label class="form-label">Phone <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="phone_number" value="{{ old('phone_number') }}">
                            @error('phone_number')
                                <span class="text-danger small">{{ $message }}</span>
                            @enderror
                        </div>

                        {{-- Role --}}
                        <div class="col-md-6">
                            <label class="form-label">Role <span class="text-danger">*</span></label>
                            <select class="form-select" name="role">
                                <option value="">Select</option>
                                @foreach ($roles as $role)
                                    <option value="{{$role->id}}">{{$role->name}}</option>
                                @endforeach
                            </select>
                            @error('role')
                                <span class="text-danger small">{{ $message }}</span>
                            @enderror
                        </div>
                    </div>

                    {{-- Permissions Table --}}
                    {{-- <div class="mt-4">
                        <div class="card">
                            <div class="card-header">
                                <strong>Module Permissions</strong>
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-bordered mb-0">
                                        <thead class="table-light">
                                            <tr>
                                                <th>Module</th>
                                                <th>Read</th>
                                                <th>Write</th>
                                                <th>Create</th>
                                                <th>Delete</th>
                                                <th>Import</th>
                                                <th>Export</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach (['Employee', 'Holidays', 'Leaves', 'Events'] as $module)
                                                <tr>
                                                    <td>{{ $module }}</td>
                                                    @foreach (['read', 'write', 'create', 'delete', 'import', 'export'] as $action)
                                                        <td class="text-center">
                                                            <input type="checkbox"
                                                                name="permissions[{{ strtolower($module) }}][{{ $action }}]"
                                                                class="form-check-input">
                                                        </td>
                                                    @endforeach
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div> --}}

                    {{-- Buttons --}}
                    <div class="mt-4 d-flex justify-content-end">
                        <button type="submit" class="btn btn-primary me-2">Add User</button>
                        <a href="{{ route('user.list-users') }}" class="btn btn-secondary">Cancel</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection
