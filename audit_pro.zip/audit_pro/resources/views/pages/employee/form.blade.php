<!-- Edit/Create Employee Modal -->
{{-- <div class="modal fade" id={{ isset($employee) ? 'edit_employee' : 'add_employee' }}>
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <div class="d-flex align-items-center">
                    <h4 class="modal-title me-2">{{ isset($employee) ? 'Edit Client' : 'Create Client' }}</h4>
                    @if (isset($employee))
                        <span>Client ID : {{ $employee->client_id }}</span>
                    @endif
                </div>
                <button type="button" class="btn-close custom-btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <i class="ti ti-x"></i>
                </button>
            </div>

            <form method="POST"
                action="{{ isset($employee) ? route('employees.update', $employee->id) : route('employees.create') }}"
                enctype="multipart/form-data">
                @csrf
                @if (isset($employee))
                    @method('PUT')
                @endif
                <div class="tab-content" id="myTabContent2">
                    <div class="tab-pane fade show active" id="basic-info2" role="tabpanel">
                        <div class="modal-body pb-0">
                            <div class="row">
                                <!-- Image Upload -->
                                <div class="col-md-12">
                                    <div
                                        class="d-flex align-items-center flex-wrap row-gap-3 bg-light w-100 rounded p-3 mb-4">
                                        <div class="avatar avatar-xxl rounded-circle border border-dashed me-2">
                                            <img src="{{ isset($employee) ? asset($employee->profile_image) : 'assets/img/users/default.jpg' }}"
                                                alt="Profile" class="rounded-circle">
                                        </div>
                                        <div class="profile-upload">
                                            <h6>Upload Profile Image</h6>
                                            <p class="fs-12">Image should be below 4 mb</p>
                                            <div class="profile-uploader d-flex align-items-center">
                                                <div class="drag-upload-btn btn btn-sm btn-primary me-2">
                                                    Upload
                                                    <input type="file" name="profile_image"
                                                        class="form-control image-sign">
                                                </div>
                                                <a href="javascript:void(0);" class="btn btn-light btn-sm">Cancel</a>
                                            </div>
                                            @error('profile_image')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <!-- First Name -->
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">First Name <span class="text-danger">*</span></label>
                                        <input type="text" name="first_name" class="form-control"
                                            value="{{ old('first_name', $employee->first_name ?? '') }}">
                                        @error('first_name')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Last Name -->
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Last Name</label>
                                        <input type="text" name="last_name" class="form-control"
                                            value="{{ old('last_name', $employee->last_name ?? '') }}">
                                        @error('last_name')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Client ID -->
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Client ID</label>
                                        <input type="text" name="client_id" class="form-control"
                                            value="{{ old('client_id', $employee->client_id ?? '') }}" disabled>
                                        @error('client_id')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Joining Date -->
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Joining Date <span
                                                class="text-danger">*</span></label>
                                        <input type="date" name="joining_date" class="form-control datetimepicker"
                                            value="{{ old('joining_date', isset($employee) ? $employee->joining_date->format('d-m-Y') : '') }}">
                                        @error('joining_date')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Username -->
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Username <span class="text-danger">*</span></label>
                                        <input type="text" name="user_name" class="form-control"
                                            value="{{ old('user_name', $employee->username ?? '') }}">
                                        @error('user_name')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Email -->
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Email <span class="text-danger">*</span></label>
                                        <input type="email" name="email" class="form-control"
                                            value="{{ old('email', $employee->email ?? '') }}">
                                        @error('email')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Phone -->
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Phone Number <span
                                                class="text-danger">*</span></label>
                                        <input type="text" name="phone_number" class="form-control"
                                            value="{{ old('phone_number', $employee->phone ?? '') }}">
                                        @error('phone_number')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Company -->
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Company <span class="text-danger">*</span></label>
                                        <input type="text" name="company" class="form-control"
                                            value="{{ old('company', $employee->company ?? '') }}">
                                        @error('company')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Address -->
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label">Address <span class="text-danger">*</span></label>
                                        <textarea name="address" class="form-control" rows="3">{{ old('address', $employee->address ?? '') }}</textarea>
                                        @error('address')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Modal Footer -->
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-light border me-2"
                                data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">
                                {{ isset($employee) ? 'Update' : 'Save' }}
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div> --}}


@extends('layouts.app')
@section('content')
    <div class="content">
        <!-- Breadcrumb -->
        <div class="d-md-flex d-block align-items-center justify-content-between page-breadcrumb mb-3">
            <div class="my-auto mb-2">
                <h2 class="mb-1">Client</h2>
                <nav>
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item">
                            <a href="{{ url('dashboard') }}"><i class="ti ti-smart-home"></i></a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="{{ route('employees.index') }}">Client</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Client
                            {{ isset($employee) ? 'Edit' : 'Create' }}</li>
                    </ol>
                </nav>
            </div>
            <div class="d-flex my-xl-auto right-content align-items-center flex-wrap ">
                <div class="mb-2">
                    <a href="{{ route('employees.index') }}" class="btn btn-primary d-flex align-items-center"><i
                            class="ti ti-arrow-left me-2"></i>Back</a>
                </div>
                <div class="head-icons ms-2">
                    <a href="javascript:void(0);" class="" data-bs-toggle="tooltip" data-bs-placement="top"
                        data-bs-original-title="Collapse" id="collapse-header">
                        <i class="ti ti-chevrons-up"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- /Breadcrumb -->
        <div class="card">
            <div class="card-body p-0">
                <form method="POST"
                    action="{{ isset($employee) ? route('employees.update', $employee->id) : route('employees.store') }}"
                    enctype="multipart/form-data">
                    @csrf
                    @if (isset($employee))
                        @method('PUT')
                    @endif
                    <div class="" id="myTabContent2">
                        <div class="pb-0 p-3">
                            <div class="row">
                                <!-- Image Upload -->
                                <div class="col-md-12">
                                    <div
                                        class="d-flex align-items-center flex-wrap row-gap-3 bg-light w-100 rounded p-3 mb-4">
                                        <div class="avatar avatar-xxl rounded-circle border border-dashed me-2">
                                            <img id="imagePreview"
                                                src="{{ isset($employee) ? env('APP_URL') . $employee->profile_img : asset('assets/img/users/user-58.jpg') }}"
                                                alt="Profile" class="rounded-circle">
                                        </div>
                                        <div class="profile-upload">
                                            <h6>Upload Profile Image</h6>
                                            <p class="fs-12">Image should be below 1 MB</p>
                                            <div class="profile-uploader d-flex align-items-center">
                                                <div class="drag-upload-btn btn btn-sm btn-primary me-2">
                                                    Upload
                                                    <input type="file" name="profile_image"
                                                        class="form-control image-sign">
                                                </div>
                                                <a href="javascript:void(0);" class="btn btn-light btn-sm">Cancel</a>
                                            </div>
                                            @error('profile_image')
                                                <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>

                                <!-- First Name -->
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">First Name <span class="text-danger">*</span></label>
                                        <input type="text" name="first_name" class="form-control"
                                            value="{{ old('first_name', $employee->first_name ?? '') }}">
                                        @error('first_name')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Last Name -->
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Last Name</label>
                                        <input type="text" name="last_name" class="form-control"
                                            value="{{ old('last_name', $employee->last_name ?? '') }}">
                                        @error('last_name')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Client ID -->
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Client ID</label>
                                        <input type="text" name="client_id" class="form-control"
                                            value="{{ old('client_id', $employee->client_id ?? '') }}" disabled>
                                        @error('client_id')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Joining Date -->
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Joining Date <span class="text-danger">*</span></label>
                                        <input type="text" name="joining_date" class="form-control datetimepicker"
                                            value="{{ old('joining_date', isset($employee) ? $employee->joining_date : '') }}">
                                        @error('joining_date')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Username -->
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Username <span class="text-danger">*</span></label>
                                        <input type="text" name="user_name" class="form-control"
                                            value="{{ old('user_name', $employee->user_name ?? '') }}">
                                        @error('user_name')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Email -->
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Email <span class="text-danger">*</span></label>
                                        <input type="email" name="email" class="form-control"
                                            value="{{ old('email', $employee->email ?? '') }}">
                                        @error('email')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Password -->
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Password
                                            @if (!isset($employee))
                                                <span class="text-danger">*</span>
                                            @endif
                                        </label>
                                        <input type="password" name="password" class="form-control">
                                        @error('password')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <!-- Confirm Password -->
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Confirm Password
                                            @if (!isset($employee))
                                                <span class="text-danger">*</span>
                                            @endif
                                        </label>
                                        <input type="password" name="password_confirmation" class="form-control">
                                        @error('password_confirmation')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Phone -->
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Phone Number <span class="text-danger">*</span></label>
                                        <input type="text" name="phone_number" class="form-control"
                                            value="{{ old('phone_number', $employee->phone_number ?? '') }}">
                                        @error('phone_number')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Company -->
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Company <span class="text-danger">*</span></label>
                                        <input type="text" name="company" class="form-control"
                                            value="{{ old('company', $employee->company ?? '') }}">
                                        @error('company')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Address -->
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label">Address <span class="text-danger">*</span></label>
                                        <textarea name="address" class="form-control" rows="3">{{ old('address', $employee->address ?? '') }}</textarea>
                                        @error('address')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Modal Footer -->
                        <div class="modal-footer mb-3 justify-content-center">
                            <button type="reset" class="btn btn-outline-light border me-2">Reset</button>
                            <button type="submit" class="btn btn-primary">
                                {{ isset($employee) ? 'Update' : 'Save' }}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
@push('scripts')
    <script>
        $(document).ready(function() {
            let originalImage = $('#imagePreview').attr('src');

            $('input[name="profile_image"]').on('change', function(event) {
                const input = event.target;

                if (input.files && input.files[0]) {
                    const reader = new FileReader();

                    reader.onload = function(e) {
                        $('#imagePreview').attr('src', e.target.result);
                    };

                    reader.readAsDataURL(input.files[0]);
                }
            });

            $('.btn-light.btn-sm').on('click', function() {
                $('input[name="profile_image"]').val('');
                $('#imagePreview').attr('src', originalImage);
            });
        });
    </script>
@endpush
