<!DOCTYPE html>
<html lang="en">

<head>
    @include('layouts.head')
</head>

@php
    $showHeader = !View::hasSection('no_header');
    $showSidebar = !View::hasSection('no_sidebar');
    $showFooter = !View::hasSection('no_footer');

    $bodyClass = collect([
        $showHeader ? null : 'no-header',
        $showSidebar ? null : 'no-sidebar',
        $showFooter ? null : 'no-footer',
    ])->filter()->implode(' ');
@endphp

<body class="{{ trim($bodyClass) }}">
    <!-- Main Wrapper -->
    <div class="main-wrapper">

        <!-- <div id="global-loader">
            <div class="page-loader"></div>
        </div> -->
        <!-- Header -->
        @if ($showHeader)
            @include('layouts.header')
        @endif
        <!-- /Header -->

        <!-- Sidebar -->
        @if ($showSidebar)
            @include('layouts.asidebar')
        @endif
        <!-- /Sidebar -->

        <!-- Page Wrapper -->
        @if ($showFooter)
            <div class="page-wrapper">
        @endif
        @yield('content')

        @if ($showFooter)
            @include('layouts.footer')
        @endif
        @if ($showFooter)
    </div>
    @endif
    <!-- /Page Wrapper -->

    </div>
    <!-- /Main Wrapper -->

    @include('layouts.vendor-js')


    @stack('scripts')
</body>


</html>
