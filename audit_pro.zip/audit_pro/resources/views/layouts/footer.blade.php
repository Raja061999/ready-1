<div class="footer d-sm-flex align-items-center justify-content-between border-top bg-white p-3">
    <p class="mb-0">copyright &copy; - {{ date('Y') }}</p>
</div>
