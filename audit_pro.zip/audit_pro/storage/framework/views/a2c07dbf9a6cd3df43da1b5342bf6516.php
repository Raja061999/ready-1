<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layouts.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<?php
    $showHeader = !View::hasSection('no_header');
    $showSidebar = !View::hasSection('no_sidebar');
    $showFooter = !View::hasSection('no_footer');

    $bodyClass = collect([
        $showHeader ? null : 'no-header',
        $showSidebar ? null : 'no-sidebar',
        $showFooter ? null : 'no-footer',
    ])->filter()->implode(' ');
?>

<body class="<?php echo e(trim($bodyClass)); ?>">
    <!-- Main Wrapper -->
    <div class="main-wrapper">

        <!-- <div id="global-loader">
            <div class="page-loader"></div>
        </div> -->
        <!-- Header -->
        <?php if($showHeader): ?>
            <?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
        <!-- /Header -->

        <!-- Sidebar -->
        <?php if($showSidebar): ?>
            <?php echo $__env->make('layouts.asidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
        <!-- /Sidebar -->

        <!-- Page Wrapper -->
        <?php if($showFooter): ?>
            <div class="page-wrapper">
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>

        <?php if($showFooter): ?>
            <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
        <?php if($showFooter): ?>
    </div>
    <?php endif; ?>
    <!-- /Page Wrapper -->

    </div>
    <!-- /Main Wrapper -->

    <?php echo $__env->make('layouts.vendor-js', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>


</html>
<?php /**PATH /var/www/html/chat/audit_pro/resources/views/layouts/app.blade.php ENDPATH**/ ?>