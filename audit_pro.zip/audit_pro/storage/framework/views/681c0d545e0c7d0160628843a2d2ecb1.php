<!-- jQuery -->
<!-- Bootstrap Core JS -->
<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>" type="text/javascript"></script>
	
    <script src="<?php echo e(asset('assets/js/jquery-3.7.1.min.js')); ?>" type="text/javascript"></script>

<!-- Feather Icon JS -->
<script src="<?php echo e(asset('assets/js/feather.min.js')); ?>" type="text/javascript"></script>

<!--Datatable JS-->
<script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>" type="text/javascript"></script>
<script src="https://smarthr.dreamstechnologies.com/html/template/assets/js/dataTables.bootstrap5.min.js" type="text/javascript"></script>

<!-- Slimscroll JS -->
<script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>" type="text/javascript"></script>

<!-- Chart JS -->
<script src="<?php echo e(asset('assets/plugins/apexchart/apexcharts.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/plugins/apexchart/chart-data.js')); ?>" type="text/javascript"></script>

<!-- Chart JS -->
<script src="<?php echo e(asset('assets/plugins/chartjs/chart.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/plugins/chartjs/chart-data.js')); ?>" type="text/javascript"></script>

<!-- Datetimepicker JS -->
<script src="<?php echo e(asset('assets/js/moment.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>" type="text/javascript"></script>

<!-- Daterangepikcer JS -->
<script src="<?php echo e(asset('assets/plugins/daterangepicker/daterangepicker.js')); ?>" type="text/javascript"></script>

<!-- Summernote JS -->
<script src="<?php echo e(asset('assets/plugins/summernote/summernote-lite.min.js')); ?>" type="text/javascript"></script>

<!-- Bootstrap Tagsinput JS -->
<script src="<?php echo e(asset('assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.js')); ?>" type="text/javascript"></script>

<!-- Select2 JS -->
<script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>" type="text/javascript"></script>

<!-- Color Picker JS -->
<script src="<?php echo e(asset('assets/plugins/@simonwep/pickr/pickr.es5.min.js')); ?>" type="text/javascript"></script>

	<!-- Custom JS -->
	<script src="<?php echo e(asset('assets/js/todo.js')); ?>" type="text/javascript"></script>
	<script src="<?php echo e(asset('assets/js/theme-colorpicker.js')); ?>" type="text/javascript"></script>
	<script src="<?php echo e(asset('assets/js/script.js')); ?>" type="text/javascript"></script>
	<script src="<?php echo e(asset('assets/js/rocket-loader.min.js')); ?>" type="text/javascript"></script>
	<script src="<?php echo e(asset('assets/js/toastr.min.js')); ?>" type="text/javascript"></script>

<script>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            toastr.error("<?php echo e($error); ?>");
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(session('error')): ?>
        toastr.error("<?php echo e(session('error')); ?>");
    <?php endif; ?>

    <?php if(session('success')): ?>
        toastr.success("<?php echo e(session('success')); ?>");
    <?php endif; ?>
</script>
<?php /**PATH /var/www/html/chat/audit_pro/resources/views/layouts/vendor-js.blade.php ENDPATH**/ ?>