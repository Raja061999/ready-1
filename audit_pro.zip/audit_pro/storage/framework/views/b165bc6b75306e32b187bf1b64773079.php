<div class="col-lg-12">
    <div class="card">
        <div class="card-body">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body pb-1">
                        <div class="border-bottom mb-3 pb-3">
                            <h4>EPF Act</h4>
                        </div>
                            <div class="row">
                                <div class="col-xxl-4 col-xl-4 d-flex">
                                    <form action="<?php echo e(route('document.store')); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                    <div class="card flex-fill">
                                        <div class="card-body">
                                            <div class="border-bottom mb-3">
                                                <div class="d-flex justify-content-between align-items-center mb-2">
                                                    <div class="d-flex align-items-center gap-3">
                                                        <span class="avatar rounded-circle bg-secondary mr-2">
                                                            <i class="ti ti-browser fs-16"></i>
                                                        </span>
                                                        <h5>PF Contribution Payment</h5>
                                                    </div>
                                                    <?php echo $__env->make('pages.document.components.status-button', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                                                    
                                                </div>
                                                <p>Used to send emails safely and easily via PHP code from a web server.</p>
                                                <div class="custom-file-container" >
                                                    <label>Upload (Single File) <a href="javascript:void(0)"
                                                            class="custom-file-container__image-clear" title="Clear Image">x</a></label>
                                                    <label class="custom-file-container__custom-file">
                                                        <input type="file"
                                                            class="custom-file-container__custom-file__custom-file-input" name="file">
                                                        <input type="hidden" name="MAX_FILE_SIZE" value="10485760">
                                                        <span class="custom-file-container__custom-file__custom-file-control"></span>
                                                    </label>
                                                    <input type="hidden" name="category" value="epf">
                                                    <input type="hidden" name="sub_category" value="pf_contribution_payment">
                                                    
                                                </div>

                                            </div>
                                            <?php echo $__env->make('pages.document.components.button', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        </div>
                                    </div>
                                    </form>
                                </div>
                                <div class="col-xxl-4 col-xl-4 d-flex">
                                    <form action="<?php echo e(route('document.store')); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                    <div class="card flex-fill">
                                        <div class="card-body">
                                            <div class="border-bottom mb-3">
                                                <div class="d-flex justify-content-between align-items-center mb-2">
                                                    <div class="d-flex align-items-center gap-3">
                                                        <span class="avatar rounded-circle bg-secondary mr-2">
                                                            <i class="ti ti-browser fs-16"></i>
                                                        </span>
                                                        <h5>Employee Enrolment (UAN)</h5>
                                                    </div>
                                                    <?php echo $__env->make('pages.document.components.status-button', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                                                    
                                                </div>
                                                <p>Used to send emails safely and easily via PHP code from a web server.</p>
                                                <div class="custom-file-container" >
                                                    <label>Upload (Single File) <a href="javascript:void(0)"
                                                            class="custom-file-container__image-clear" title="Clear Image">x</a></label>
                                                    <label class="custom-file-container__custom-file">
                                                        <input type="file"
                                                            class="custom-file-container__custom-file__custom-file-input" name="file">
                                                        <input type="hidden" name="MAX_FILE_SIZE" value="10485760">
                                                        <span class="custom-file-container__custom-file__custom-file-control"></span>
                                                    </label>
                                                    <input type="hidden" name="category" value="epf">
                                                    <input type="hidden" name="sub_category" value="employee_enrolment">
                                                    
                                                </div>

                                            </div>
                                            <?php echo $__env->make('pages.document.components.button', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                                        </div>
                                    </div>
                                    </form>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end card body -->
    </div>
</div>
<?php /**PATH /var/www/html/chat/audit_pro/resources/views/pages/document/components/epf.blade.php ENDPATH**/ ?>