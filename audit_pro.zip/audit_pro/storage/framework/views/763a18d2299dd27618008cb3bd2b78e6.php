<div class="footer d-sm-flex align-items-center justify-content-between border-top bg-white p-3">
    <p class="mb-0">copyright &copy; - <?php echo e(date('Y')); ?></p>
</div>
<?php /**PATH /var/www/html/chat/audit_pro/resources/views/layouts/footer.blade.php ENDPATH**/ ?>