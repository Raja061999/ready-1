<?php $__env->startSection('content'); ?>


<div class="">
    <div class="content">

        <!-- Breadcrumb -->
        <div class="d-md-flex d-block align-items-center justify-content-between page-breadcrumb mb-3">
            <div class="my-auto mb-2">
                <h2 class="mb-1">Document Form</h2>
                <nav>
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item">
                            <a href="index.html"><i class="ti ti-smart-home"></i></a>
                        </li>
                        <li class="breadcrumb-item">
                            Documents
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Document Form</li>
                    </ol>
                </nav>
            </div>
            <div class="head-icons ms-2">
                <a href="javascript:void(0);" class="" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Collapse" id="collapse-header">
                    <i class="ti ti-chevrons-up"></i>
                </a>
            </div>
        </div>
        <!-- /Breadcrumb -->
        <div class="card">
            <div class="card-body p-3">
                <div class="d-flex align-items-center justify-content-between flex-wrap row-gap-3">
                    <h5>Add Date</h5>
                    <div class="d-flex align-items-center flex-wrap row-gap-3 gap-3">
                        <div class="input-icon-end position-relative">
                            <input type="text" class="form-control datetimepicker" placeholder="dd/mm/yyyy">
                            <span class="input-icon-addon">
                                <i class="ti ti-calendar text-gray-7"></i>
                            </span>
                        </div>
                        
                        
                        <button class="btn btn-sm btn-outline-primary d-inline-flex align-items-center p-2" type="submit">
                            Add Date
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <ul class="nav nav-tabs nav-tabs-solid bg-transparent border-bottom mb-3" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" data-bs-toggle="tab" href="#income-tax-tab" role="tab">
                    <i class="ti ti-settings me-2"></i> Income Tax Act
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#epf-act-tab" role="tab">
                    <i class="ti ti-settings me-2"></i> EPF Act
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#esi-tab" role="tab">
                    <i class="ti ti-settings me-2"></i> ESI Act
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#state-pt-tab" role="tab">
                    <i class="ti ti-settings me-2"></i> State PT Acts
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#state-lwf-tab" role="tab">
                    <i class="ti ti-settings me-2"></i> State LWF Acts
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#bonus-tab" role="tab">
                    <i class="ti ti-settings me-2"></i> Bonus Act
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#gratuity-tab" role="tab">
                    <i class="ti ti-settings me-2"></i> Gratuity Act
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#contract-labour-tab" role="tab">
                    <i class="ti ti-settings me-2"></i> Contract Labour Act
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#clra-tab" role="tab">
                    <i class="ti ti-settings me-2"></i> CLRA + EPF + ESI
                </a>
            </li>


        </ul>
        <div class="row">
            <div class="tab-content">
                <div class="tab-pane fade show active" id="income-tax-tab" role="tabpanel">
                    <?php echo $__env->make('pages.document.components.income-tax', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <div class="tab-pane fade" id="epf-act-tab" role="tabpanel">
                    <?php echo $__env->make('pages.document.components.epf', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <div class="tab-pane fade" id="esi-tab" role="tabpanel">
                    <?php echo $__env->make('pages.document.components.esi', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <div class="tab-pane fade" id="state-pt-tab" role="tabpanel">
                    <?php echo $__env->make('pages.document.components.state-pt', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <div class="tab-pane fade" id="state-lwf-tab" role="tabpanel">
                    <?php echo $__env->make('pages.document.components.state-lwf', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <div class="tab-pane fade" id="bonus-tab" role="tabpanel">
                    <?php echo $__env->make('pages.document.components.bonus', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <div class="tab-pane fade" id="gratuity-tab" role="tabpanel">
                    <?php echo $__env->make('pages.document.components.gratuity', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <div class="tab-pane fade" id="contract-labour-tab" role="tabpanel">
                    <?php echo $__env->make('pages.document.components.contract-labour', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <div class="tab-pane fade" id="clra-tab" role="tabpanel">
                    <?php echo $__env->make('pages.document.components.clra-epf-esi', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>

        </div>
    </div>
    <div class="footer d-sm-flex align-items-center justify-content-between border-top bg-white p-3">
        <p class="mb-0">2014 - 2025 &copy; SmartHR.</p>
        <p>Designed &amp; Developed By <a href="javascript:void(0);" class="text-primary">Dreams</a></p>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/chat/audit_pro/resources/views/pages/document/form.blade.php ENDPATH**/ ?>