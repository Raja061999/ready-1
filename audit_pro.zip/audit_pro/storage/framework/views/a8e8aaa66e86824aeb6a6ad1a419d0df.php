<?php $__env->startSection('no_header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('no_sidebar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('no_footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid min-vh-100 d-flex justify-content-center align-items-center">
        <div class="col-md-4">
            <form method="POST" action="<?php echo e(route('login.post')); ?>">
                <?php echo csrf_field(); ?>
                <div class="d-flex flex-column justify-content-between p-4">

                    
                    <div class="mb-5 text-center">
                        <img src="<?php echo e(asset('images/logo.png')); ?>" class="img-fluid" alt="Logo">
                    </div>

                    
                    <div class="text-center mb-3">
                        <h2 class="mb-2">Sign In</h2>
                        <p class="mb-0">Please enter your details to sign in</p>
                    </div>

                    
                    <div class="mb-3">
                        <label class="form-label">Email Address</label>
                        <div class="input-group">
                            <input type="text" name="email" value="<?php echo e(old('email')); ?>" class="form-control border-end-0">
                            <span class="input-group-text border-start-0">
                                <i class="ti ti-mail"></i>
                            </span>
                        </div>
                    </div>

                    
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <div class="pass-group">
                            <input type="password" name="password" class="pass-input form-control">
                            <span class="ti toggle-password ti-eye-off"></span>
                        </div>
                    </div>

                    
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <div class="form-check form-check-md mb-0">
                            <input class="form-check-input" name="remember" id="remember_me" type="checkbox">
                            <label for="remember_me" class="form-check-label mt-0">Remember Me</label>
                        </div>
                        <div class="text-end">
                            <a href="<?php echo e(route('password.request')); ?>" class="link-danger">Forgot Password?</a>
                        </div>
                    </div>

                    
                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary w-100">Sign In</button>
                    </div>

                    
                    <div class="mt-5 pb-4 text-center">
                        <p class="mb-0 text-gray-9">&copy; <?php echo e(date('Y')); ?> - Company Name</p>
                    </div>

                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/chat/audit_pro/resources/views/pages/auth/login.blade.php ENDPATH**/ ?>