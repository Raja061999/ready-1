<div class="d-flex align-items-center justify-content-start gap-2">
    <button class="btn btn-sm d-inline-flex align-items-center btn-dark" type="submit">
        <i class="ti ti-checks me-1"></i>
            Upload
    </button>
    <button class="btn btn-sm d-inline-flex align-items-center btn-success">
        <i class="ti ti-checks me-1"></i>
            Approve
    </button>
    <button class="btn btn-sm d-inline-flex align-items-center btn-success">
        <i class="ti ti-checks me-1"></i>
            Approved
    </button>

    <button class="btn btn-sm d-inline-flex align-items-center btn-danger" >
        <i class="ti ti-checks me-1"></i>
            Reject
    </button>
    <button class="btn btn-sm d-inline-flex align-items-center btn-danger" >
        <i class="ti ti-checks me-1"></i>
            Rejected
    </button>

    
</div>

<?php /**PATH /var/www/html/chat/audit_pro/resources/views/pages/document/components/button.blade.php ENDPATH**/ ?>