<button class="btn btn-sm btn-outline-warning d-inline-flex align-items-center" type="submit">
    Pending
</button>
<?php /**PATH /var/www/html/chat/audit_pro/resources/views/pages/document/components/status-button.blade.php ENDPATH**/ ?>