<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateClientsTable extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('clients', function (Blueprint $table) {
            $table->id();
            $table->string('first_name', 100);
            $table->string('last_name', 100)->nullable();
            $table->string('client_id', 150)->nullable();
            $table->string('user_name', 150)->nullable();
            $table->string('email', 250)->nullable();
            $table->longText('address')->nullable();
            $table->string('phone_number', 255)->nullable();
            $table->string('company', 100)->nullable();
            $table->string('profile_img', 250)->nullable();
            $table->date('joining_date')->nullable();
            $table->tinyInteger('status')->default(1);
            $table->longText('password');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('clients');
    }
}
