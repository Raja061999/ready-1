<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;

class AccessControlSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $admin = Role::where('name', 'admin')->first();
        $admin->syncPermissions([
            //user
            'user_view',
            'user_edit',
            'user_delete',

            //role
            'role_view',
            'role_edit',
            'role_delete',

            //permission
            'permission_view',

            //agent
            'client_view',
            'client_edit',
            'client_delete',
        ]);

        $client = Role::where('name', 'client')->first();
        $client->syncPermissions([
            //agent
            'client_view',
            'client_edit',
            'client_delete',
        ]);
    }
}
