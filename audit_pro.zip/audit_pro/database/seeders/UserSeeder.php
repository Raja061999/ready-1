<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;

class UserSeeder extends Seeder
{
    public function run(): void
    {

        $users = [
            [
                'name'      => 'Admin',
                'email'     => 'admin@gmail.com',
                'password'  => 'admin@123',
                'phone'     => '9876543210',
                'roleName'  => 'admin',
            ],
            [
                'name'      => 'John Doe',
                'email'     => 'johndoe@gmail.com',
                'password'  => 'john@123',
                'phone'     => '9123456780',
                'roleName'  => 'client',
            ],
        ];

        foreach ($users as $userData) {
            $role = Role::where('name', $userData['roleName'])->first();

            $user = User::updateOrCreate(
                ['email' => $userData['email']],
                [
                    'name'              => $userData['name'],
                    'password'          => Hash::make($userData['password']),
                    'phone_number'      => $userData['phone'],
                    'email_verified_at' => now(),
                    'role_id'           => $role->id,
                ]
            );

            $user->assignRole($role);
        }
    }
}
