<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;

class RoleSeeder extends Seeder
{
    public function run(): void
    {
        $roles = [
            'admin',
            'client'
        ];

        foreach ($roles as $key => $value) {
            Role::create(['name' => $value]);
        }
    }
}
