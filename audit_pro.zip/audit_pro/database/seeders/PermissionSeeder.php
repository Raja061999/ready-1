<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class PermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $permissions = [
            // User permissions
            ['name' => 'user_view', 'title' => 'View', 'group' => 'User'],
            ['name' => 'user_edit', 'title' => 'Edit', 'group' => 'User'],
            ['name' => 'user_delete', 'title' => 'Delete', 'group' => 'User'],

            // Role permissions
            ['name' => 'role_view', 'title' => 'View', 'group' => 'Role'],
            ['name' => 'role_edit', 'title' => 'Edit', 'group' => 'Role'],
            ['name' => 'role_delete', 'title' => 'Delete', 'group' => 'Role'],

            // Permission permissions
            ['name' => 'permission_view', 'title' => 'View', 'group' => 'Permission'],

            // Admin permissions
            ['name' => 'client_view', 'title' => 'View', 'group' => 'Client'],
            ['name' => 'client_edit', 'title' => 'Edit', 'group' => 'Client'],
            ['name' => 'client_delete', 'title' => 'Delete', 'group' => 'Client'],
        ];

        foreach ($permissions as $key => $value) {
            Permission::create($value);
        }
    }
}
