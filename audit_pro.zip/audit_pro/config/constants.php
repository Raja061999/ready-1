<?php


return [
    'document_file_extantion' => ['xlsx','pdf','jpg','jpeg'],
]


?>