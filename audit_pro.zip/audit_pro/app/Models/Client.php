<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    protected $fillable = [
        'first_name',
        'last_name',
        'client_id',
        'user_name',
        'email',
        'phone_number',
        'company',
        'profile_img',
        'address',
        'joining_date',
        'password'
    ];
}
