<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Document extends Model
{
       protected $fillable = [
        'client_id',
        'category',
        'sub_category',
        'file_name',
        'status'
    ];
}
