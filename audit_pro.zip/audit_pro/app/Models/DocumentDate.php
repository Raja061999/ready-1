<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DocumentDate extends Model
{
    protected $table = 'document_dates';
    protected $fillable = [
        'date'
    ];
}
