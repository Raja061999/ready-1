<?php

namespace App\Helpers;

use Exception;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;

class Helper
{
 public static function uploadFiles($file, string $path): string
    {
        $extensionList = config('constants.document_file_extantion');

        $extension = strtolower($file->getClientOriginalExtension());

        if (!in_array($extension,config('constants.document_file_extantion'))) {
            throw new Exception("Only " . implode(", ", $extensionList) . " files are allowed", 422);
        }
        $filenameOri = config("constants.prefix") . uniqid();

        $originalName = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);

        $timestamp = now()->format('His');

        $filename = config('constants.prefix') . $timestamp . '.' . $extension;

        $storagePath = $file->storeAs("public/{$path}", $filename);
          if (!$storagePath) {
            throw new Exception("Failed to upload the file to local storage", 500);
        }
        return Storage::url("{$path}/{$filename}");
    }
    public static function dashboardRoute()
    {
        $user = Auth::user();

        if ($user && $user->hasRole('admin')) {
            return route('dashboard.admin');
        } elseif ($user && $user->hasRole('client')) {
            return route('dashboard.client');
        }

      //  return route('dashboard.general');
    }

}
?>
