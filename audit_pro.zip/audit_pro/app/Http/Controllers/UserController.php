<?php

namespace App\Http\Controllers;

use App\Http\Requests\Usermanagement\UserRequest;
use App\Http\Requests\Usermanagement\UserUpdateRequest;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;
use Yajra\DataTables\DataTables;

class UserController extends Controller
{
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $users = User::with('role')->select('users.*');

            return DataTables::of($users)
                ->addIndexColumn()
                ->addColumn('role', function ($user) {
                    return $user->role->name ?? '-';
                })
                ->addColumn('status', function ($user) {
                    return $user->status ? 'Active' : 'Inactive';
                })

                ->addColumn('created_at', function ($user) {
                    return Carbon::parse($user->created_at)->format('d-m-Y H:i'); 
                })

                ->addColumn('action', function ($user) {
                    $edit = route('user.edit-user', ['id' => $user->id]);
                    $delete = route('user.delete-user', ['id' => $user->id]);

                    return '
                        <div class="action-icon d-inline-flex">
                            <a href="' . $edit . '" class="me-2"><i class="ti ti-edit"></i></a>
                            <a href="' . $delete . '"><i class="ti ti-trash"></i></a>
                        </div>';
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('pages.usermanagement.list-user');
    }

    public function role(Request $request)
    {
        if ($request->ajax()) {
            $data = Role::select(['id', 'name', 'guard_name', 'created_at']);

            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($row) {
                    return '<a href="#" class="btn btn-sm btn-primary">Edit</a>';
                })
                ->rawColumns(['action'])
                ->make(true);
        }

        return view('pages.usermanagement.role');
    }

    public function create(Request $request)
    {
        $roles = Role::get();
        return view('pages.usermanagement.create-user', compact('roles'));
    }


    public function store(UserRequest $request)
    {
        $validated = $request->validated();

        // Create the user
        $user = User::create([
            'name'         => $validated['full_name'],
            'email'        => $validated['email'],
            'password'     => Hash::make($validated['password']),
            'phone_number' => $validated['phone_number'],
            'role_id'      => $validated['role'],
        ]);

        // Assign role using Spatie
        if (!empty($validated['role'])) {
            $role = Role::find($validated['role']);
            if ($role) {
                $user->assignRole($role->name);
            }
        }

        // // Assign permissions (optional)
        // if (!empty($validated['permissions'])) {
        //     $user->syncPermissions($validated['permissions']); // expects array of permission names
        // }

        return redirect()->route('user.list-users');
    }

    public function edit($id)
    {
        $user = User::find($id);
        $roles = Role::get();
        return view('pages.usermanagement.edit-user', compact('user', 'roles'));
    }


    public function update(UserUpdateRequest $request)
    {
        $user = User::findOrFail($request->id);

        $validated = $request->validated();

        $user->name         = $validated['full_name'];
        $user->email        = $validated['email'];
        $user->phone_number = $validated['phone_number'];
        $user->role_id      = $validated['role'];

        // Only update password if filled
        if (!empty($validated['password'])) {
            $user->password = Hash::make($validated['password']);
        }
        $user->save();

        return redirect()->route('user.list-users')->with('success', 'User updated successfully.');
    }


    public function delete($id)
    {
        $user = User::find($id);
        $user->delete();
        return redirect()->route('user.list-users')->with('success', 'User deleted successfully.');
    }

    public function myProfile(){
        $user = Auth::user();
        return view('pages.dashboards.my_profile',compact('user'));
    }

    public function myProfileUpdate(Request $request){
        dd($request->all());
        return view('pages.dashboards.my_profile',compact('user'));
    }
}
