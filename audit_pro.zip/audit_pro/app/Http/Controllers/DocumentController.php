<?php

namespace App\Http\Controllers;

use App\Helpers\Helper;
use App\Models\Document;
use App\Models\DocumentDate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class DocumentController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $clientId = Auth::user()->id;
        $data = Document::where('client_id',$clientId)->get();
        return view('pages.document.list',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {

        return view('pages.document.form');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        try {
        $validator = Validator::make($request->all(), [
            'file' => 'required|file|mimes:xlsx,xls,pdf,jpg,jpeg|max:10240',
            'category' => 'required',
            'sub_category' => 'required',
        ]);

          if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $clientId = Auth::user()->id;
        $file = $request->file;
        $category = $request->category ?? 'No Category';
        $subCategory = $request->sub_category ?? 'No SubCategory';
        $path = $clientId."/". $category . "/" . $subCategory;

        $fileName = Helper::uploadFiles($file,$path);

        $data = new Document;
        $data['client_id'] = $clientId;
        $data['category'] = $request->category;
        $data['sub_category'] = $request->sub_category;
        $data['file_name'] = $fileName;
        $data->save();

         return response()->json([
            'status' => true,
            'message' => 'File uploaded successfully',
        ]);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => 'Something went wrong',
                'error' => $th->getMessage()
            ], 500);

        }
    }

    public function storeDate(Request $request){

        try {

            $data = DocumentDate::create($request->all());
            return redirect()->back()->with('success', 'Date added successfully');
        } catch (\Throwable $th) {

            return redirect()->back()->withErrors(['error' => 'Something went wrong: ' . $th->getMessage()]);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
