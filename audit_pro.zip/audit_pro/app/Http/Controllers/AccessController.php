<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Yajra\DataTables\Facades\DataTables;
class AccessController extends Controller
{
    public function roleList(Request $request)
    {
        if ($request->ajax()) {
            $users = Role::select(['id', 'name','created_at','status'])->get();
            return DataTables::of($users)->make(true);
        }
        return view('pages.usermanagement.role');
    }
}
