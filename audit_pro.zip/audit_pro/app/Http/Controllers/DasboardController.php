<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DasboardController extends Controller
{
    public function admin_dasboard()
    {
        return view('pages.dashboards.admin_dashboard');
    }

    public function client_dashboard()
    {
        return view('pages.dashboards.client_dashboard');
    }
}
