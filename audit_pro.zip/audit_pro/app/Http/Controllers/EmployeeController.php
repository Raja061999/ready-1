<?php

namespace App\Http\Controllers;

use App\Models\Client;
use Carbon\Carbon;
use Exception;
use Illuminate\Container\Attributes\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\Facades\DataTables;

class EmployeeController extends Controller
{
    protected $clientModal;
    public function __construct(Client $clientModal)
    {
        $this->clientModal = $clientModal;
    }

    public function index(Request $request)
    {
        try {
            $title = "Clients List";
            $today = Carbon::today()->toDateString();

            $clientCounts = Client::selectRaw("
                COUNT(*) as total_clients,
                COUNT(CASE WHEN status = '1' THEN 1 END) as active_clients,
                COUNT(CASE WHEN status = '0' THEN 1 END) as inactive_clients,
                COUNT(CASE WHEN DATE(created_at) = ? THEN 1 END) as new_clients_today
            ", [$today])->first();

            if ($request->ajax()) {
                $clientsList = $this->clientModal->get();
                $table = DataTables::of($clientsList);
                $table->editColumn('status', function ($request) {
                    $badge = $request->status == 1 ? 'Active' : 'In-Active';
                    return $badge;
                    // return "<span class='badge badge-{$badge} d-inline-flex align-items-center badge-xs'></span>";
                });
                $table->editColumn('action', function ($request) {
                    $actions = '<div class="d-flex justify-content-center">';
                    $actions .= "<a href='" . route('employees.edit', $request->id) . "' class='me-2'><i class='ti ti-edit'></i></a>";
                    $actions .= '</div>';
                    return $actions;
                })
                    ->escapeColumns([])
                    ->setRowId('id');
                return $table->make(true);
            }
            return view('pages.employee.list', compact('title', 'clientCounts'));
        } catch (\Exception $e) {
            return redirect()->back()->withErrors(['error' => 'Failed to fetch clients: ' . $e->getMessage()]);
        }
    }

    public function store(Request $request)
    {
        try {
            $validator = $this->commonClientValidation("create", $request);
            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }
            // $rules = [
            //     'first_name' => 'required',
            //     'last_name' => 'required',
            //     'user_name' => 'required',
            //     'email' => 'required',
            //     'phone_number' => 'required',
            //     'company' => 'required',
            //     'joining_date' => 'required',
            //     'address' => 'required'
            // ];
            // if ($request->hasFile('profile_image')) {
            //     $rules['profile_image'] = 'nullable|image|mimes:jpg,jpeg,png|max:1024';
            // }
            // $validator = Validator::make($request->all(), $rules);

            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }
            if ($request->hasFile('profile_image')) {
                $file = $request->file('profile_image');
                $filename = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
                $file->move(public_path('assets/profileimages'), $filename);
                $data['profile_image'] = 'assets/profileimages/' . $filename;
                $request->merge(['profile_img' => $data['profile_image']]);
            }
            //Creae Clients
            $ClientData = $this->clientModal->create([
                'first_name' => $request->first_name,
                'last_name' => $request->last_name,
                'user_name' => $request->user_name,
                'email' => $request->email,
                'phone_number' => $request->phone_number,
                'company' => $request->company,
                'address' => $request->address,
                'profile_img' => isset($request->profile_img) ? $request->profile_img : NULL,
                'joining_date' => Carbon::parse($request->joining_date)->format('Y-m-d'),
                'password'=> Hash::make($request->password),
            ]);
            $clientId = str_pad($ClientData->id, 4, '0', STR_PAD_LEFT);
            $ClientData->client_id = 'CID-' . $clientId;
            $ClientData->save();
            //
            return redirect()->route('employees.index');
        } catch (\Exception $e) {

            return redirect()->back()->withErrors(['error' => 'Failed to create clients: ' . $e->getMessage()]);
        }
    }

    public function create()
    {
        try {
            $title = "Clients Create";
            return view('pages.employee.form', compact('title'));
        } catch (Exception $e) {
            return redirect()->back()->withErrors(['error' => 'Failed to create clients: ' . $e->getMessage()]);
        }
    }

    public function edit($id)
    {
        try {
            $title = "Clients Edit";
            $employee = $this->clientModal->where('id', $id)->first();
            return view('pages.employee.form', compact('title', 'employee'));
        } catch (Exception $e) {
            return redirect()->back()->withErrors(['error' => 'Failed to create clients: ' . $e->getMessage()]);
        }
    }

    public function update($id, Request $request)
    {
        try {
            $validator = $this->commonClientValidation("update", $request);
            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }
            // $rules = [
            //     'id' => 'required',
            //     'first_name' => 'required',
            //     'last_name' => 'required',
            //     'user_name' => 'required',
            //     'email' => 'required',
            //     'phone_number' => 'required',
            //     'company' => 'required',
            //     'joining_date' => 'required',
            //     'address' => 'required'
            // ];
            // if ($request->hasFile('profile_image')) {
            //     $rules['profile_image'] = 'nullable|image|mimes:jpg,jpeg,png|max:1024';
            // }
            // $validator = Validator::make($request->all(), $rules);

            // if ($validator->fails()) {
            //     return redirect()->back()->withErrors($validator)->withInput();
            // }
            $UpdateClients = $this->clientModal->where('id', $id)->first();

            if ($UpdateClients) {
                $updationData = [
                    'first_name'    => $request->first_name,
                    'last_name'     => $request->last_name,
                    'user_name'     => $request->user_name,
                    'email'         => $request->email,
                    'phone_number'  => $request->phone_number,
                    'company'       => $request->company,
                    'address'       => $request->address,
                    'password'      => $request->filled('password')? Hash::make($request->password): $UpdateClients->password,
                ];

                if ($request->hasFile('profile_image')) {
                    $file = $request->file('profile_image');
                    $filename = time() . '_' . $file->getClientOriginalName();
                    $file->move(public_path('assets/profileimages'), $filename);
                    $updationData['profile_img'] = 'assets/profileimages/' . $filename;
                } else {
                    $updationData['profile_img'] = $UpdateClients->profile_img;
                }

                // Update the model
                $UpdateClients->update($updationData);
            }
            return redirect()->route('employees.index');
        } catch (Exception $e) {
            return redirect()->back()->withErrors(['error' => 'Failed to create clients: ' . $e->getMessage()]);
        }
    }

    public function commonClientValidation($type, $request)
    {
        $rules = [
            'first_name' => 'required',
            'last_name' => 'required',
            'user_name' => 'required|unique:clients,user_name' . ($type == 'update' ? ',' . $request->id : ''),
            'email' => 'required|unique:clients,email' . ($type == 'update' ? ',' . $request->id : ''),
            'phone_number' => 'required|max:10',
            'company' => 'required',
            'joining_date' => 'required',
            'address' => 'required'
        ];
        if (isset($request->password) && $type == 'create') {
            $rules['password'] = 'required|string|min:6|confirmed';
            $rules['password_confirmation'] = 'required|string|min:6';
        }
        if ($request->hasFile('profile_image')) {
            $rules['profile_image'] = 'nullable|image|mimes:jpg,jpeg,png|max:1024';
        }
        $validator = Validator::make($request->all(), $rules);
        return $validator;

    }
    public function show1(){
        return view('pages.employee.show1');
    }
}
