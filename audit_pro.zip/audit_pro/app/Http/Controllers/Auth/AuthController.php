<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use App\Models\User;
use Exception;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    public function showLoginForm()
    {
        try {
            return view('pages.auth.login');
        } catch (Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }


    public function login(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
                'password' => 'required|string|min:6',
            ]);

            if ($validator->fails()) {
                return back()
                    ->withErrors($validator)
                    ->withInput();
            }

            $credentials = $request->only('email', 'password');

            if (auth()->attempt($credentials)) {
                $user = auth()->user();

                // 🔁 Role-based redirect
                if ($user->hasRole('admin')) {
                    return redirect()->route('dashboard.admin');
                }

                if ($user->hasRole('client')) {
                    return redirect()->route('dashboard.client');
                }
            }

            return back()->with('error', 'Invalid email or password.');
        } catch (Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }

    public function logout(Request $request)
    {
        try {
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return redirect()->route('login');
        } catch (Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }

    public function showForgotPasswordForm()
    {
        try {
            return view('pages.auth.forgotpassword');
        } catch (Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }
    public function showResetForm()
    {
        try {
            return view('pages.auth.reset-password');
        } catch (Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }
    public function successPage()
    {
        try {
            return view('pages.auth.success');
        } catch (Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }


    public function sendOtp(Request $request)
    {
        try {
            $request->validate([
                'email' => 'required|email',
            ]);

            $user = User::where('email', $request->email)->first();

            if (!$user) {
                return redirect()->back()->with('error', 'Please enter a valid and registered email address');
            }

            $otp = rand(1000, 9999);

            $user->otp = $otp;
            $user->otp_expires_at = now()->addMinutes(10);
            $user->save();

            Mail::raw("Your OTP is: $otp", function ($message) use ($user) {
                $message->to($user->email)
                    ->subject('Your Password Reset OTP');
            });

            return redirect()->route('password.otp_form')->with([
                'success' => 'OTP sent to your registered email address.',
                'email' => $user->email
            ]);
        } catch (Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
    public function showOtpForm()
    {
        try {
            return view('pages.auth.email-verification');
        } catch (Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }
}
