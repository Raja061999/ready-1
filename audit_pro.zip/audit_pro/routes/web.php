<?php

use App\Http\Controllers\AccessController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\DasboardController;
use App\Http\Controllers\DocumentController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\EmployeeController;
use Illuminate\Support\Facades\Artisan;

/*
|--------------------------------------------------------------------------
| Guest Routes (no auth required)
|--------------------------------------------------------------------------
*/

Route::controller(AuthController::class)->group(function () {
    // Login
    Route::get('/', 'showLoginForm')->name('login');
    Route::post('/login', 'login')->name('login.post');

    // Forgot Password Step 1: Request OTP
    Route::get('/forgot-password', 'showForgotPasswordForm')->name('password.request');
    Route::post('/forgot-password', 'sendOtp')->name('password.send_otp');

    // Step 2: Enter OTP
    Route::get('/verify-otp', 'showOtpForm')->name('password.otp_form');
    Route::post('/verify-otp', 'verifyOtp')->name('password.verify_otp');

    // Step 3: Enter New Password
    Route::get('/reset-password', 'showResetForm')->name('password.reset_form');
    Route::post('/reset-password', 'updatePassword')->name('password.update');


    // Step 4: Success Page
    Route::get('/success', 'successPage')->name('success');
});

/*
|--------------------------------------------------------------------------
| Authenticated Routes (auth required)
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'no.cache'])->group(function () {

    // Dashboard
    Route::prefix('dashboard')->name('dashboard.')->controller(DasboardController::class)->group(function(){
        Route::get('admin-dashboard', 'admin_dasboard')->name('admin');
        Route::get('client-dashboard', 'client_dashboard')->name('client');
    });

    // // User Management Routes
    Route::prefix('user')->name('user.')->controller(UserController::class)->group(function () {
        Route::get('/list-users', 'index')->name('list-users');
        Route::get('/create-user', 'create')->name('create-user');
        Route::post('/store-user', 'store')->name('store-user');
        Route::get('/edit-user/{id}', 'edit')->name('edit-user');
        Route::post('/update-user', 'update')->name('update-user');
        Route::get('/delete-user/{id}', 'delete')->name('delete-user');
        Route::get('/role', 'role')->name('role');
        Route::get('/my-profile','myProfile')->name('my-profile');
        Route::post('/my-profile/update','myProfileUpdate')->name('my-profile-update');
    });

    Route::prefix('access')->name('access.')->controller(AccessController::class)->group(function () {
        Route::get('/role', 'roleList')->name('role');
    });

    // Employee Routes
    Route::prefix('employees')->name('employees.')->controller(EmployeeController::class)->group(function () {
        Route::get('/list', 'index')->name('index');
        Route::get('create', 'create')->name('create');
        Route::post('store', 'store')->name('store');
        Route::get('/edit/{id}', 'edit')->name('edit');
        Route::put('/{id}', 'update')->name('update');
        Route::delete('/{id}', 'destroy')->name('destroy');
        Route::get('/show1','show1')->name('show1');
    });

    // Logout route (optional but recommended)
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
    //Document Routes
    Route::prefix('document')->controller(DocumentController::class)->name('document.')->group(function () {
        Route::get('/index', 'index')->name('index');
        Route::get('/create', 'create')->name('create');
        Route::post('/store', 'store')->name('store');
        Route::post('/store-date','storeDate')->name('store-date');
    });
});


Route::get('/migrate-fresh', function () {
    Artisan::call('migrate:fresh --seed');
    return response()->json(['message' => 'Database migrated and seeded successfully.']);
});

