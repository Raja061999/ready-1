import { useState } from 'react';
import './App.css';
import ChartExample from './Charts/PieChart';
import MixBar from './Charts/StackedBar';
import Vertical from './Charts/verticalChart';
import { Barchart2, Barchart3 } from './Charts/BarChart2';
import XYChart from './Charts/xyzChart';
import MyChart from './Charts/stackedChart';
import DonutChart from './Charts/DonutChart';
import CharjsPie from './Charts/CharjsPie';
import ApexRadialChart from './Charts/ApexRadialBar';
import ApexBarChart from './Charts/ApexBarChart';
import SyncingCharts from './Charts/SlineBar';
import ApexChart from './Charts/ApexChart';
import StackedCloumn from './Charts/StakedCloumn';
import ColumnData from './Charts/Column';
// import { getData } from './Charts/PieData';


function App() {
  const [chartName, setChartName] = useState("piechart");

  const chartDesign = () => {
    console.log("chartName", chartName)
    switch (chartName) {
      case "piechart":
        return <ChartExample />;
      case "mixbar":
        return <MixBar />;
      case "vertical":
        return <Vertical />;
      case "barchart":
        return <Barchart2 />;
      case "barchart2":
        return <Barchart3 />;
      case "xyz":
        return <XYChart />;
      case "stacked":
        return <MyChart />;
      case "donut":
        return <DonutChart />;
      case "chartJsPie":
        return <CharjsPie />;
      case "apexradialChart":
        return <ApexRadialChart />;
      case "apexBarChart":
        return <ApexBarChart />;
      case "spline":
        return <SyncingCharts />;
      case "apexchart":
        return <ApexChart />;
      case "StackedCloumn":
        return <StackedCloumn />;
        case "ColumnData":
        return <ColumnData />;
      default:
        return null;
    }
  };

  return (
    <div className="App">
      <div>
        <button onClick={() => setChartName("piechart")}>PieChart</button>
        <button onClick={() => setChartName("mixbar")}>MixBar</button>
        <button onClick={() => setChartName("vertical")}>Vertical</button>
        <button onClick={() => setChartName("barchart")}>barchart</button>
        <button onClick={() => setChartName("barchart2")}>barchart2</button>
        <button onClick={() => setChartName("xyz")}>xyz</button>
        <button onClick={() => setChartName("stacked")}>stacked</button>
        <button onClick={() => setChartName("donut")}>DonutChart</button>
        <button onClick={() => setChartName("chartJsPie")}>chartJsPie</button>
        <button onClick={() => setChartName("apexradialChart")}>ApexRadialChart</button>
        <button onClick={() => setChartName("apexBarChart")}>ApexBarChart</button>
        <button onClick={() => setChartName("spline")}>spline</button>
        <button onClick={() => setChartName("apexchart")}>apexchart</button>
        <button onClick={() => setChartName("StackedCloumn")}>StackedCloumn</button>
        <button onClick={() => setChartName("ColumnData")}>ColumnData</button>
     
     
     
      </div>
      <div>
        {chartDesign()}
      </div>
    </div>
  );
}

export default App;
