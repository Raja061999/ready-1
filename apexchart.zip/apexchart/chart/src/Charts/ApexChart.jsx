import React, { useEffect,useState } from 'react';
import ApexCharts from 'apexcharts';


export default function ApexChart() {
  useEffect(() => {

    var options4 = {
      series: [{
      name: 'timesheet',
      data: [2.00,5.00, 1.00, 5.00, 22,10]
    }, {
      name: 'cric match',
      data: [5.00,3.00, 2.00, 1.00, 13,45]
    }, {
      name: 'hrms',
      data: [1.00, 1.00,5.00, 2.00, 22,36]
    }],
      chart: {
      type: 'bar',
      width: 560,
        height: 350,
      stacked: true,
      toolbar: {
        show: false
      }
    },
    title: {
      text: 'Time Sheet-Employee View',
      align: 'center',
    },
    responsive: [{
      breakpoint:280,
      options: {
        legend: {
          position: 'bottom',
                offsetX: -10,
          offsetY: 0
        }
      }
    }],
    plotOptions: {
      bar: {
        horizontal: false,
        borderRadius: 10,
        borderRadiusApplication: 'end', // 'around', 'end'
        borderRadiusWhenStacked: 'last', // 'all', 'last'
        dataLabels: {
          total: {
            enabled: true,
            style: {
              fontSize: '13px',
              fontWeight: 900
            }
          }
        }
      },
    },
    dataLabels: {
      enabled: false
    },
    xaxis: {
      type: 'datetime',
      categories: ['01/01/2011 GMT', '01/02/2011 GMT', '01/03/2011 GMT', '01/04/2011 GMT',
        '01/05/2011 GMT','01/06/2011 GMT'
      ],
    },
    };
  
  

    var options3 = {
      series: [{
     data: [44, 55, 57, 56]
    }, {
      data: [76, 85, 101, 98]
    }, {
      data: [35, 41, 36, 26]
    }],
    labels: ['Completed', 'In Progress', 'Pending'],
      chart: {
      type: 'bar',
      height: 350
    },
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: '55%',
        endingShape: 'rounded'
      },
    },
    dataLabels: {
      enabled: false
    },
    stroke: {
      show: true,
      width: 2,
      colors: ['transparent']
    },
    xaxis: {
      categories: ['Sprint 1', 'Sprint 2', 'Sprint 3', 'Sprint 4'],
    },
    yaxis: {
      title: {
        text: '$ (thousands)'
      }
    },
    fill: {
      opacity: 1
    },
    title: {
      text: 'Task status-sprint wise',
      align: 'center',
    },
    tooltip: {
      y: {
        formatter: function (val) {
          return "$ " + val + " thousands"
        }
      }
    }
    };
  
  
    var options1=  {
        series: [5,3,8,7],
        labels: ['Ongoing', 'Onhold', 'Overdue', 'Completed'],
        chart: {
          width: 420,
          type: 'donut',
        },
        plotOptions: {
          pie: {
            startAngle: -90,
            endAngle: 270,
          },
        },
        dataLabels: {
          enabled: false,
        },
        fill: {
          type: 'gradient',
        },
        legend: {
          formatter: function (val, opts) {
            return val + ' - ' + opts.w.globals.series[opts.seriesIndex];
          },
        },
        title: {
          text: 'Project Status',
          align: 'center',
        },
        responsive: [
          {
            breakpoint: 480,
            options: {
              chart: {
                width: 200,
              },
              legend: {
                position: 'bottom',
              },
            },
          },
        ],
      }    

    var chart2 = new ApexCharts(document.querySelector("#chart2"), options1);
    chart2.render();
    var chart3 = new ApexCharts(document.querySelector("#chart3"), options3);
    chart3.render();
    var chart4 = new ApexCharts(document.querySelector("#chart4"), options4);
    chart4.render();


    // Cleanup chart on component unmount
    return () => {
      chart2.destroy();
      chart3.destroy();
      chart4.destroy();

    };
  }, []); // Run only once when the component mounts


  return (
    <div className='flex flex-col items-center w-screen h-screen bg-red gap-5 py-10'>
        <div id="chart2" className='h-[350px] w-[450px]'>
      </div>
      <div id="html-dist"></div>
      <div id="chart3"  className='h-[350px] w-[450px]'></div>
      <div id="chart4"  className='h-[350px]'></div>
     </div>
  );
}
