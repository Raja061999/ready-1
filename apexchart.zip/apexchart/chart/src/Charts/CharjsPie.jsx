import React, { useEffect, useState } from 'react';
import { Pie } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';

// Register required components for Chart.js
ChartJS.register(ArcElement, Tooltip, Legend);

function ChartjsPie() {
    const [chartData, setChartData] = useState(null); // Start with null to handle conditional rendering

    const getChartData = () => {
        setChartData({
            labels: ['Boston', 'Worcester', 'Springfield', 'Lowell', 'Cambridge', 'New Bedford'],
            datasets: [
                {
                    label: 'Population',
                    data: [617594, 18045, 153060, 106519, 105162, 95072],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.6)',
                        'rgba(54, 162, 235, 0.6)',
                        'rgba(255, 206, 86, 0.6)',
                        'rgba(75, 192, 192, 0.6)',
                        'rgba(153, 102, 255, 0.6)',
                        'rgba(255, 159, 64, 0.6)',
                    ],
                },
            ],
        });
    };

    useEffect(() => {
        getChartData();
    }, []);

    return (
        <div style={{ width: '30%', margin: '0 auto' }}>
            {/* Render Pie only if chartData is available */}
            {chartData ? (
                <Pie
                    data={chartData}
                    options={{
                        responsive: true,
                        plugins: {
                            title: {
                                display: true,
                                text: 'Largest Cities in Massachusetts',
                                font: {
                                    size: 20,
                                },
                            },
                            legend: {
                                display: true,
                                position: 'right',
                            },
                        },
                    }}
                />
            ) : (
                <p>Loading chart data...</p>
            )}
        </div>
    );
}

export default ChartjsPie;
