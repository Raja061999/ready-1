
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

// Sample data (you can replace this with dynamic data)
const data = [
  { name: 'task A', completed: 40, inprogress: 24, pending: 24 },
  { name: 'task B', completed: 30, inprogress: 13, pending: 22 },
  { name: 'task C', completed: 20, inprogress: 98, pending: 22 },
  { name: 'task D', completed: 27, inprogress: 39, pending: 20 },
  { name: 'task E', completed: 18, inprogress: 48, pending: 21 },
  { name: 'task F', completed: 23, inprogress: 38, pending: 25 },
  { name: 'task G', completed: 34, inprogress: 43, pending: 21 },
];

const MixBar = () => {
  return (
    <ResponsiveContainer width="100%" height={600}>
      <BarChart
        width={500}
        height={600}
        data={data}
        margin={{
          top: 20,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Bar dataKey="completed" stackId="a" fill="#8884d8" />
        <Bar dataKey="inprogress" stackId="a" fill="#82ca9d" />
        <Bar dataKey="pending" fill="#ffc658" />
      </BarChart>
    </ResponsiveContainer>
  );
};

export default MixBar;

