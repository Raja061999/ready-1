import React, { useState } from "react";
import { AgCharts } from "ag-charts-react";
import { getData } from "./PieData";


const ChartExample = () => {
  const [options] = useState({
    autoSize: true, // This ensures the chart resizes automatically
    data: getData(),
    title: {
      text: "Project Status",
    },
  
    height:600,
    
    series: [
      {
        type: "pie",
        angleKey: "num",
        calloutLabelKey: "asset",
        sectorLabelKey: "num",
        sectorLabel: {
          color: "white",
          fontWeight: "bold",
          formatter: ({ value }) => `${(value ).toFixed(0)}`,
        },
        
      },
    ],
  });

  return (
    <div style={{ width: "100%", height: "500px" }}> {/* Set a height for the div */}
      < AgCharts options={options} /> {/* Correct component */}
    </div>
  );
};

export default ChartExample