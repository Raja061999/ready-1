import React, { useState } from 'react';
import ReactApexChart from 'react-apexcharts';

// const ApexRadialChart = () => {
//     const [chartOptions] = useState({
//         series: [76, 67, 61, 90],
//         options: {
//             chart: {
//                 height: 390,
//                 type: 'radialBar',
//             },
//             plotOptions: {
//                 radialBar: {
//                     offsetY: 0,
//                     startAngle: 0,
//                     endAngle: 270,
//                     hollow: {
//                         margin: 5,
//                         size: '30%',
//                         background: 'transparent',
//                         image: undefined,
//                     },
//                     dataLabels: {
//                         name: {
//                             show: false,
//                         },
//                         value: {
//                             show: false,
//                         },
//                     },
//                 },
//             },
//             colors: ['#1ab7ea', '#0084ff', '#39539E', '#0077B5'],
//             labels: ['Vimeo', 'Messenger', 'Facebook', 'LinkedIn'],
//             responsive: [
//                 {
//                     breakpoint: 480,
//                     options: {
//                         legend: {
//                             show: false,
//                         },
//                     },
//                 },
//             ],
//         },
//     });

//     return (
//         <div>
//             <div id="chart">
//                 <ReactApexChart
//                     options={chartOptions.options}
//                     series={chartOptions.series}
//                     type="radialBar"
//                     height={390}
//                 />
//             </div>
//             <div id="html-dist"></div>
//         </div>
//     );
// };




const ApexBarChart = () => {
    // Define the data for the chart
    const seriesData = {
        monthDataSeries1: {
            prices: [8107.85, 8128.0, 8123.2, 8195.5, 8245.7, 8231.0, 8221.8, 8297.8, 8305.7, 8310.9],
            dates: [
                '2024-01-01',
                '2024-01-02',
                '2024-01-03',
                '2024-01-04',
                '2024-01-05',
                '2024-01-06',
                '2024-01-07',
                '2024-01-08',
                '2024-01-09',
                '2024-01-10',
            ],
        },
    };

    const [barChart] = useState({
        series: [
            {
                name: 'STOCK ABC',
                data: seriesData.monthDataSeries1.prices,
            },
        ],
        options: {
            chart: {
                type: 'area',
                height: 350,
                zoom: {
                    enabled: false,
                },
            },
            dataLabels: {
                enabled: false,
            },
            stroke: {
                curve: 'straight',
            },
            title: {
                text: 'Fundamental Analysis of Stocks',
                align: 'left',
            },
            subtitle: {
                text: 'Price Movements',
                align: 'left',
            },
            labels: seriesData.monthDataSeries1.dates,
            xaxis: {
                type: 'datetime',
            },
            yaxis: {
                opposite: true,
            },
            legend: {
                horizontalAlign: 'left',
            },
        },
    });

    return (
        <div style={{ width: '50%', margin: 'auto' }}>
            <div id="chart">
                <ReactApexChart
                    options={barChart.options}
                    series={barChart.series}
                    type="line"
                    height={350}
                />
            </div>
        </div>
    );
};

export default ApexBarChart;