import React, { useEffect } from 'react';
import ApexCharts from 'apexcharts';

const SyncingCharts = () => {
  useEffect(() => {
    const generateDayWiseTimeSeries = (baseval, count, yrange) => {
      let i = 0;
      const series = [];
      while (i < count) {
        const x = baseval;
        const y = Math.floor(Math.random() * (yrange.max - yrange.min + 1)) + yrange.min;
        series.push([x, y]);
        baseval += 86400000; // Increment by 1 day
        i++;
      }
      return series;
    };

    const options = {
      series: [
        {
          name: 'North',
          data: generateDayWiseTimeSeries(
            new Date('11 Feb 2017 GMT').getTime(),
            20,
            { min: 10, max: 20 }
          ),
        },
      ],
    
      chart: {
        id: 'chart1',
        group: 'social',
        type: 'area',
        height: 250,
        // sparkline: {
        //     enabled: true
        // },
        toolbar: {
            show: false
          },
        stacked: true,
        events: {
          selection: function (chart, e) {
            console.log(new Date(e.xaxis.min));
          },
        },
      },
      colors: ['#008FFB', '#00E396', '#CED4DC'],
      dataLabels: {
        enabled: false,
        // offsetY: -40,
      },
      stroke: {
        curve: 'smooth',
      },
      fill: {
        type: 'gradient',
        gradient: {
          opacityFrom: 0.6,
          opacityTo: 0.8,
        },
      },
      legend: {
        position: 'top',
        horizontalAlign: 'left',
      },
      xaxis: {
        type: 'datetime',
      },
      grid: {
        borderColor: 'red',
        strokeDashArray: 16,
      }
      
      
    };

    // Ensure the chart is created after DOM is available
    const chartContainer = document.querySelector('#chart1');
    if (chartContainer) {
      const chart1 = new ApexCharts(chartContainer, options);
      chart1.render();

      // Cleanup function to destroy the chart on unmount
      return () => {
        chart1.destroy();
      };
    } else {
      console.error("Chart container with ID 'chart1' not found");
    }
  }, []);

  return (
    <div style={{width:"500px",margin:"auto",height:"200px"}}>
      {/* Ensure this div exists for the chart */}
      <div id="chart1"></div>
    </div>
  );
};

export default SyncingCharts;
