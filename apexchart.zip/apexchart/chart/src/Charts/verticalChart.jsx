import React from 'react';
import {
  ComposedChart,
  Line,
  Area,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

const data = [
    { name: 'task A', completed: 40, inprogress: 24, pending: 24 },
    { name: 'task B', completed: 30, inprogress: 13, pending: 22 },
    { name: 'task C', completed: 20, inprogress: 98, pending: 22 },
    { name: 'task D', completed: 27, inprogress: 39, pending: 20 },
    { name: 'task E', completed: 18, inprogress: 48, pending: 21 },
    { name: 'task F', completed: 23, inprogress: 38, pending: 25 },
    { name: 'task G', completed: 34, inprogress: 43, pending: 21 },
  ];
 const Vertical =() => {
    return (
        <ResponsiveContainer width="100%" height={600}>
        <ComposedChart
          layout="vertical"
          width={500}
          height={400}
          data={data}
          margin={{
            top: 20,
            right: 20,
            bottom: 20,
            left: 20,
          }}
        >
          <CartesianGrid stroke="#f5f5f5" />
          <XAxis type="number" />
          <YAxis dataKey="name" type="category" scale="band" />
          <Tooltip />
          <Legend />
          <Area dataKey="completed" fill="#8884d8" stroke="#8884d8" />
          <Bar dataKey="inprogress" barSize={20} fill="#413ea0" />
          <Line dataKey="pending" stroke="#ff7300" />
        </ComposedChart>
       
      </ResponsiveContainer>
    );
  
}

export default Vertical

